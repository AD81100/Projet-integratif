(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.sticky-top').addClass('shadow-sm').css('top', '0px');
        } else {
            $('.sticky-top').removeClass('shadow-sm').css('top', '-100px');
        }
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: false,
        loop: true,
        nav: true,
        navText : [
            '<i class="bi bi-chevron-left"></i>',
            '<i class="bi bi-chevron-right"></i>'
        ]
    });

    
})(jQuery);

// 一下是转换背景颜色
const daymode = document.getElementById('daymode');
const nightmode = document.getElementById('nightmode');
const body = document.getElementsByTagName('body')[0];

const nav=document.getElementById('topnav');
const nav_prevesion=document.getElementById('topnav_prevesion');


const title1=document.getElementById('littletitle1');
const title2=document.getElementById('littletitle2');
const title3=document.getElementById('littletitle3');
const title4=document.getElementById('littletitle4');


//index.html
daymode.addEventListener('click', function() {
  if (this.checked) {
        body.classList.remove('night');
        nav.classList.remove('night');
        nav.classList.add('day');
        nav_prevesion.classList.add('day');
        nav_prevesion.classList.remove('night');

        title1.classList.remove('night');
        title1.classList.add('day');
        title2.classList.remove('night');
        title2.classList.add('day');
        title3.classList.remove('night');
        title3.classList.add('day');
        title4.classList.remove('night');
        title4.classList.add('day');

  }


  });

nightmode.addEventListener('click', function() {
    if (this.checked) {
        body.classList.add('night');
        nav.classList.add('night');
        nav.classList.remove('day');
        nav_prevesion.classList.add('night');
        nav_prevesion.classList.remove('day');

        title1.classList.add('night');
        title1.classList.remove('day');
        title2.classList.add('night');
        title2.classList.remove('day');
        title3.classList.add('night');
        title3.classList.remove('day');
        title4.classList.add('night');
        title4.classList.remove('day');
    }
});


var searchKeyWord = document.getElementById('btn_keyword');
searchKeyWord.addEventListener('click',function ()
{
    var searchText=document.getElementById('keywords').value;
    searchAndHighLiht(searchText);
});

function searchAndHighLiht(searchText)
{
    var textNode=document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        null,
        false
    );
    while (textNode.nextNode())
    {
        var node=textNode.currentNode;
        if(node.nodeValue.indexOf(searchText)!==-1)
        {
            var parent=node.parentNode;
            var span=document.createElement('span');
            span.style.color='red';
            span.textContent=searchText;

            parent.replaceChild(span,node);
        }
    }
}





