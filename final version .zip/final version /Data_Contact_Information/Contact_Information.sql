-- MySQL dump 10.13  Distrib 8.0.32, for macos13 (arm64)
--
-- Host: 127.0.0.1    Database: Contact_Information
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Client` (
  `codeClient` int NOT NULL AUTO_INCREMENT,
  `nomClient` varchar(20) DEFAULT NULL,
  `prenomClient` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `objet` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  PRIMARY KEY (`codeClient`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Client`
--

LOCK TABLES `Client` WRITE;
/*!40000 ALTER TABLE `Client` DISABLE KEYS */;
INSERT INTO `Client` (`codeClient`, `nomClient`, `prenomClient`, `email`, `telephone`, `objet`, `message`, `Date`) VALUES (1,'tutu','toto','toto@tutu.com','123456','test','-\r\n-\r\n-','2023-03-14');
/*!40000 ALTER TABLE `Client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Manager`
--

DROP TABLE IF EXISTS `Manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Manager` (
  `CodeManager` int NOT NULL AUTO_INCREMENT,
  `NomManager` varchar(20) DEFAULT NULL,
  `prenomManager` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CodeManager`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Manager`
--

LOCK TABLES `Manager` WRITE;
/*!40000 ALTER TABLE `Manager` DISABLE KEYS */;
INSERT INTO `Manager` (`CodeManager`, `NomManager`, `prenomManager`, `email`) VALUES (1,'Liu','Tiantian','tian-tian.liu@ut-capitole.fr'),(2,'Ma','Zhuo','zhuo.ma@ut-capitole.fr'),(3,'Durdu','Arif','arif.durdu@ut-capitole.fr'),(4,'Boualem','Ilies','ilies.boualem@ut-capitole.fr');
/*!40000 ALTER TABLE `Manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `News`
--

DROP TABLE IF EXISTS `News`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `News` (
  `CodeNews` int NOT NULL AUTO_INCREMENT,
  `TitleNews` varchar(2000) NOT NULL,
  `DateNews` date NOT NULL,
  `CodeManager` int NOT NULL,
  `ContenuNews` varchar(2000) NOT NULL,
  PRIMARY KEY (`CodeNews`),
  KEY `News_Manager_CodeManager_fk` (`CodeManager`),
  CONSTRAINT `News_Manager_CodeManager_fk` FOREIGN KEY (`CodeManager`) REFERENCES `Manager` (`CodeManager`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `News`
--

LOCK TABLES `News` WRITE;
/*!40000 ALTER TABLE `News` DISABLE KEYS */;
INSERT INTO `News` (`CodeNews`, `TitleNews`, `DateNews`, `CodeManager`, `ContenuNews`) VALUES (1,'Précautions à prendre en forêt ou proximité immédiate','2023-03-12',1,'Se renseigner sur les conditions météorologiques avant de se rendre en forêt;\nAvoir un téléphone portable sur soi pour alerter les secours en cas de besoin;\nPrévenir ses proches de l’itinéraire emprunté;\nRespecter les chemins balisés;\nNe jamais allumer de feu en forêt, dans les bois ou à proximité, même s’il s’agit d’un barbecue;\nNe jamais jeter de mégots de cigarette dans une zone boisée ou par la fenêtre de la voiture;\nPrendre garde à l’endroit où est stationnée la voiture : le pot d’échappement à haute température peut enflammer l’herbe sèche;\nVeiller à camper dans un lieu autorisé, sécurisé et protégé;\nRespecter les interdictions d’accès aux zones boisées;'),(2,'Habitation proche des forêt','2023-03-12',1,'Les habitations situées en forêt font l’objet d’une réglementation spécifique stricte.\nSe renseigner auprès de la mairie et du centre de secours le plus proche pour connaître toutes les réglementations à respecter.\nObligation de débroussailler les abords des lieux d’habitation situé en forêt ou à proximité.\nLe non-respect de cette obligation peut entraîner une contravention pouvant atteindre 1.500 euros ;\nNe pas mettre des gouttières en plastiques ;\nNe pas stocker à proximité immédiate de la maison le bois, le fuel et le butane ;\nEn cas de feu et s’il y a une piscine dans la propriété, la mettre à disposition des sapeurs-pompiers ;\nNe pas planter de végétaux trop proche de la maison.\nEviter de planter des chênes Kermès, des cyprès,des mimosas, des eucalyptus, des végétaux épineux et des conifères, ce sont des plantes très inflammables ;\nCouper les branches des arbres pour qu’elles soient à plus de 3 mètres de la façade ;\nNe rien brûler entre avril et septembre.');
/*!40000 ALTER TABLE `News` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Objet`
--

DROP TABLE IF EXISTS `Objet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Objet` (
  `CodeObjet` int NOT NULL AUTO_INCREMENT,
  `CodeClient` int NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Contenu` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`CodeObjet`),
  KEY `Objet_Client_codeClient_fk` (`CodeClient`),
  CONSTRAINT `Objet_Client_codeClient_fk` FOREIGN KEY (`CodeClient`) REFERENCES `Client` (`codeClient`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Objet`
--

LOCK TABLES `Objet` WRITE;
/*!40000 ALTER TABLE `Objet` DISABLE KEYS */;
INSERT INTO `Objet` (`CodeObjet`, `CodeClient`, `Title`, `Contenu`) VALUES (1,1,'test','-\r\n-\r\n-');
/*!40000 ALTER TABLE `Objet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Verifier`
--

DROP TABLE IF EXISTS `Verifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Verifier` (
  `CodeObjet` int DEFAULT NULL,
  `CodeManager` int DEFAULT NULL,
  `DateVerifier` date DEFAULT NULL,
  KEY `Verifier_Manager_CodeManager_fk` (`CodeManager`),
  KEY `Verifier_Objet_CodeObjet_fk` (`CodeObjet`),
  CONSTRAINT `Verifier_Manager_CodeManager_fk` FOREIGN KEY (`CodeManager`) REFERENCES `Manager` (`CodeManager`),
  CONSTRAINT `Verifier_Objet_CodeObjet_fk` FOREIGN KEY (`CodeObjet`) REFERENCES `Objet` (`CodeObjet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Verifier`
--

LOCK TABLES `Verifier` WRITE;
/*!40000 ALTER TABLE `Verifier` DISABLE KEYS */;
/*!40000 ALTER TABLE `Verifier` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-14 17:11:32
