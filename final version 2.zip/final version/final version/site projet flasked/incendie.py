from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
from flask import url_for
import newspaper
from newspaper import Article
import os
import pymysql
import requests
import json
import csv
import datetime
import http.client, urllib.parse
from PIL import Image
import sqlite3
import statistics
import datetime
import requests
import json
from unidecode import unidecode


app = Flask(__name__)


def connect(host_name:str,user:str,pwd:str,datebase_name:str):
    try:
        mydb = pymysql.connect(
          host=host_name,
          user=user,
          password=pwd,
          database=datebase_name
        )
        print("Connection to database successful!")
        return mydb
    except:
        print("Connection to database failed!")

def createConnection_Sqlite():
    path = "db/db_incendie.db"
    if not os.path.exists(path):
        print(f"Le fichier {path} n'existe pas")
        connection = None
    else:
        try:
            connection = sqlite3.connect(path)
            print("Connection to SQLite réussie")
        except sqlite3.Error as e:
            print(f"The error {e} occured")
    return connection

def execute_requete(connection, query):
    cursor = connection.cursor()
    try:
        cursor.execute(query)
    except sqlite3.Error as e:
        return(f"L'erreur {e} est apparu")
    return(cursor.fetchall())


def meteo_direct(city1, city2):
    # on enlève les accents de la première ville

    city1 = remove_accents(city1)

    # gestion des cas particuliers

    if city1 == "La_Rochelle":
        city1 = "rochelle-17"
    elif city1 == "Aubusson":
        city1 = "aubusson-23"
    elif city1 == "Marmande":
        city1 = "Agen"
    elif city1 == "Lure":
        city1 = "lure-70"
    elif city1 == "Clamecy":
        city1 = "clamecy-58"

        # on va chercher le JSON sur l'api

    api1 = requests.get(f"https://prevision-meteo.ch/services/json/{city1}")
    api_city1 = api1.text
    api_clean_city1 = json.loads(api_city1)

    # on récupère la température et l'humidité

    temperature_city1 = api_clean_city1['current_condition']['tmp']
    humidity_city1 = api_clean_city1['current_condition']['humidity']

    score_city1 = 0

    # gestion des scores pour déterminer la couleur plus tard

    if temperature_city1 >= 35:
        score_city1 += 3
    elif 34 >= temperature_city1 > 25:
        score_city1 += 2
    elif 24 >= temperature_city1 > 19:
        score_city1 += 1
    elif 18 >= temperature_city1 > 15:
        score_city1 += 0
    elif 14 >= temperature_city1 > 5:
        score_city1 -= 1
    else:
        score_city1 -= 2

    if humidity_city1 < 20:
        score_city1 += 2
    elif 21 <= humidity_city1 < 25:
        score_city1 += 1
    elif 26 <= humidity_city1 < 40:
        score_city1 += 0
    elif 27 <= humidity_city1 <= 50:
        score_city1 -= 2
    else:
        score_city1 -= 3

        # on fait pareil pour la ville 2

    city2 = remove_accents(city2)

    if city2 == "La_Rochelle":
        city2 = "rochelle-17"
    elif city2 == "Aubusson":
        city2 = "aubusson-23"
    elif city2 == "Marmande":
        city2 = "Agen"
    elif city2 == "Lure":
        city2 = "lure-70"
    elif city2 == "Clamecy":
        city2 = "clamecy-58"

    api2 = requests.get(f"https://prevision-meteo.ch/services/json/{city2}")
    api_city2 = api2.text
    api_clean_city2 = json.loads(api_city2)
    temperature_city2 = api_clean_city2['current_condition']['tmp']
    humidity_city2 = api_clean_city2['current_condition']['humidity']

    score_city2 = 0

    if temperature_city2 >= 35:
        score_city2 += 3
    elif 34 >= temperature_city2 > 25:
        score_city2 += 2
    elif 24 >= temperature_city2 > 19:
        score_city2 += 1
    elif 18 >= temperature_city2 > 15:
        score_city2 += 0
    elif 14 >= temperature_city2 > 5:
        score_city2 -= 1
    else:
        score_city2 -= 2

    if humidity_city2 < 20:
        score_city2 += 2
    elif 21 <= humidity_city2 < 25:
        score_city2 += 1
    elif 26 <= humidity_city2 < 40:
        score_city2 += 0
    elif 27 <= humidity_city2 <= 50:
        score_city2 -= 2
    else:
        score_city2 -= 3

    # calcul du score moyen en direct pour le département

    score = (score_city1 + score_city2) / 2

    return (score)

def remove_accents(word):
    return unidecode(word)

#select
def execute_select(mydb,query):
    mycursor = mydb.cursor()
    mycursor.execute(query)
    result = mycursor.fetchall()
    return result
#insert
def execute_insert(mydb,query):
    mycursor = mydb.cursor()
    mycursor.execute(query)
    mydb.commit()

# Obtenir des données d’actualités
def info_get():
    # CodeNews TitleNews   DateNews ContenuNews
    # Connection API
    conn = http.client.HTTPConnection('api.mediastack.com')
    params = urllib.parse.urlencode({
        'access_key': 'bcd039ca7a33bf023f8682d2e30b8ff6',
        'categories': 'general',
        'languages': 'fr',
        'sort': 'published_desc',
        'limit': 10,
        'countries': 'fr',
        'keywords': 'incendie',
    })
    conn.request('GET', '/v1/news?{}'.format(params))
    res = conn.getresponse()
    data = res.read()
    data = data.decode('utf-8')

    allNews = json.loads(data)
    TitleNews = []
    ContenuNews = []
    DateNews = []
    UrlNews = []
    for info in allNews['data']:
        TitleNews.append(info['title'])
        UrlNews.append(info['url'])
        dateT = info['published_at']
        dateu = dateT[:10]
        DateNews.append(dateu)

    for u in range(len(UrlNews)):
        url = str(UrlNews[u])
        article = Article(url)
        article.download()
        article.parse()
        limited_text = article.text[:350]
        ContenuNews.append(limited_text)

    with open('news.csv', 'w', encoding='utf-8', newline='') as f:
        fieldnames = ['TitleNews', 'ContenuNews', 'DateNews']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for i in range(len(TitleNews)):
            writer.writerow({'TitleNews': TitleNews[i], 'ContenuNews': ContenuNews[i], 'DateNews': DateNews[i]})

    # Insérez les données du fichier CSV dans la base de données
    mydb = connect('localhost', 'root', 'ccyy4820', 'Contact_Information')  
    cursor = mydb.cursor()
    
    with open('news.csv', 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            cursor.execute("INSERT INTO news (TitleNews, ContenuNews, DateNews) VALUES (%s, %s, %s)",
                           (row['TitleNews'], row['ContenuNews'], row['DateNews']))
            mydb.commit()
    mydb.close()

@app.route('/')
def index():
    return render_template('layout.html')

@app.route('/index')
def index_html():
    mydb = connect('localhost', 'root', 'ccyy4820', 'Contact_Information')
    query='''
        SELECT TitleNews,ContenuNews
        FROM News
        ORDER BY DateNews DESC
        LIMIT 2;
    '''
    result = execute_select(mydb, query)
    result = list(result)
    result = dealwith_news(result)
    mydb.close()
    return render_template('index.html',news=result)
@app.route('/prevision')
def prevision():
    return render_template('prevision.html')
@app.route('/france')

def date_plus_proche():
    aujourdhui = datetime.date.today()
    if aujourdhui.day <= 5:
        return f"01/{aujourdhui.month:02d}"
    elif aujourdhui.day <= 15:
        return f"10/{aujourdhui.month:02d}"
    elif aujourdhui.day <= 25:
        return f"20/{aujourdhui.month:02d}"
    else:
        next_month = aujourdhui.month + 1
        if next_month > 12:
            next_month = 1
        return f"01/{next_month:02d}"

def moyenne_departement(city1, city2, date):
    alert_level_city1 = get_average_alert_level(city1, date)
    alert_level_city2 = get_average_alert_level(city2, date)
    average_alert_level = (alert_level_city1 + alert_level_city2) / 2
    direct = meteo_direct(city1, city2)
    moyenne = (average_alert_level + direct) /2
    color = get_color(moyenne)
    return color

date = date_plus_proche()

def get_color(value):
    rounded_value = round(value)
    if 0 <= rounded_value <= 5:
        return "green"
    elif 6 <= rounded_value <= 10:
        return "orange"
    elif 11 <= rounded_value <= 15:
        return "red"
    elif 16 <= rounded_value <= 20:
        return "black"
    else:
        return "unknown"
def get_average_alert_level(city, date):
    connection = createConnection_Sqlite()
    c = connection.cursor()

    alerte = []
    for i in range(2018, 2022):
        date_format = f"{date}/{i}"
        query = f"""SELECT e.nivAlerte
                    FROM Etat_DFCI e, DFCI d
                    WHERE e.codeDFCI = d.codeDFCI
                    AND e.dateEtat = '{date_format}'
                    AND d.nomDFCI = '{city}';"""

        c.execute(query)
        results = c.fetchone()

        alerte.append(int(results[0]))

    avg_alert_level = statistics.mean(alerte)


    return avg_alert_level
def france():
    return render_template('france.html')

@app.route('/corse')
def corse():
    ajc = moyenne_departement("Ajaccio", "Ajaccio", date)
    bst = moyenne_departement("Bastia", "Bastia", date)
    return render_template('corse.html', ajc=ajc, bst=bst)

@app.route('/paca')
def paca():
    adhp = moyenne_departement("Castellane", "Barcelonnette", date)
    ha = moyenne_departement("Gap", "Briançon", date)
    am = moyenne_departement("Nice", "Grasse", date)
    bdr = moyenne_departement("Marseille", "Aix-en-Provence", date)
    var = moyenne_departement("Toulon", "Brignoles", date)
    vaucluse = moyenne_departement("Avignon", "Apt", date)

    return render_template('paca.html', adhp=adhp, ha=ha, am=am, bdr=bdr, var=var, vaucluse=vaucluse)

@app.route('/aquitaine')
def aquitaine():
    gironde = moyenne_departement("Bordeaux", "Arcachon", date)
    charente = moyenne_departement("Angoulême", "Cognac", date)
    correze = moyenne_departement("Tulle", "Brive-la-Gaillarde", date)
    creuse = moyenne_departement("Gueret", "Aubusson", date)
    dordogne = moyenne_departement("Périgueux", "Bergerac", date)
    landes = moyenne_departement("Mont-de-Marsan", "Dax", date)
    lot_garonne = moyenne_departement("Agen", "Marmande", date)
    charente_maritime = moyenne_departement("La_Rochelle", "Rochefort", date)
    pyr_atlantique = moyenne_departement("Pau", "Bayonne", date)
    deux_sevre = moyenne_departement("Niort", "Bressuire", date)
    vienne = moyenne_departement("Poitiers", "Châtellerault", date)
    h_vienne = moyenne_departement("Limoges", "Bellac", date)

    return render_template('aquitaine.html', h_vienne=h_vienne, vienne=vienne, deux_sevre=deux_sevre,
                           pyr_atlantique=pyr_atlantique, charente_maritime=charente_maritime, lot_garonne=lot_garonne,
                           landes=landes, dordogne=dordogne, creuse=creuse, correze=correze, gironde=gironde,
                           charente=charente)


@app.route('/occitanie')
def occitanie():
    gard = moyenne_departement("Nîmes", "Alès", date)
    herault = moyenne_departement("Montpellier", "Béziers", date)
    porientale = moyenne_departement("Perpignan", "Céret", date)
    aude = moyenne_departement("Carcassonne", "Limoux", date)
    lozere = moyenne_departement("Mende", "Florac", date)

    return render_template('occitanie.html', gard=gard, herault=herault, porientale=porientale, aude=aude,
                           lozere=lozere)

@app.route('/bourgogne')
def bourgogne():
    coteor = moyenne_departement("Dijon", "Montbard", date)
    doubs = moyenne_departement("Besançon", "Montbéliard", date)
    jura = moyenne_departement("Lons-le-Saunier", "Dole", date)
    nievre = moyenne_departement("Nevers", "Clamecy", date)
    h_saone = moyenne_departement("Vesoul", "Lure", date)
    saoneloire = moyenne_departement("Autun", "Charolles", date)
    yonne = moyenne_departement("Auxerre", "Avallon", date)
    belfort = moyenne_departement("Belfort", "Belfort", date)
    return render_template('bourgogne.html', belfort=belfort, yonne=yonne, saoneloire=saoneloire, coteor=coteor,
                           doubs=doubs, jura=jura, nievre=nievre, h_saone=h_saone)

@app.route('/information')
def information():
    info_get()
    mydb=connect('localhost', 'root', 'ccyy4820', 'Contact_Information')
    # today = datetime.date.today()
    query='''
    SELECT TitleNews,ContenuNews
    FROM News
    ORDER BY DateNews DESC
    LIMIT 2
    '''
    result=execute_select(mydb,query)
    result = list(result)
    result=dealwith_news(result)
    mydb.close()
#[('',''),('','')]
    return render_template('information.html',news=result)

def dealwith_news(result:list)->dict:
    #dic={title1:contenu,title2:contenu}
    dic={}
    for i in result:
        dic[i[0]]=i[1]
    return dic

@app.route('/contact')
def contact():
    return render_template('contact.html')

#montre toutes les news
@app.route('/MoreNews')
def MoreNews():
    mydb = connect('localhost', 'root', 'ccyy4820', 'Contact_Information')
    query = f'''    select distinct TitleNews,ContenuNews from News
           '''
    result_keyword = execute_select(mydb, query)
    mydb.close()

    dic = {}
    for title, content in result_keyword:
        dic[title] = content
    return render_template('MoreNews.html',news=dic)





@app.route('/keywords',methods=['GET','POST'])
def Keywords():
    if request.method=='GET':
        keyword=request.args.get('keywords')
    else:
        keyword=request.form['keywords']
    dic={}

    if len(keyword)==0:
        text="Rien d'affiche "
        return render_template('pour_afficher_keyword.html',text=text,keyword=dic)
    else:
        mydb = connect('localhost', 'root', 'ccyy4820', 'Contact_Information')
        query=f'''
            select distinct TitleNews,ContenuNews from News
            where ContenuNews like '%{keyword}%'
            or TitleNews like '%{keyword}%'
            '''
        result_keyword=execute_select(mydb,query)
        mydb.close()
        for title,content in result_keyword:
            dic[title]=content
        text=""
        return render_template('pour_afficher_keyword.html',keyword=dic,text=text)





@app.route('/confirmation',methods=['GET','POST'])
def confirmation():
    if request.method == 'GET':
        nom=request.args.get('nom')
        prenom=request.args.get('prenom')
        email=request.args.get('email')
        telephone=request.args.get('telephone')
        object=request.args.get('object')
        message=request.args.get('message')

    else:
        nom=request.form['nom']
        prenom = request.form['prenom']
        email=request.form['email']
        telephone = request.form['telephone']
        object = request.form['object']
        message = request.form['message']
    today = datetime.date.today()
    now = datetime.datetime.now()
    date_str = today.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")

    # info=f"{nom},{prenom},{email}.{telephone},{object},{message},{date_str}"
    # return render_template('confirmation.html', info=info)

    #connect db
    mydb = connect('localhost', 'root', 'ccyy4820', 'Contact_Information')
    query=f'''
    insert into Client(nomClient, prenomClient, email, telephone, objet, message, Date)
    value ('{nom}','{prenom}','{email}','{telephone}','{object}','{message}','{date_str}')
    '''

    result_client=execute_insert(mydb,query)
    codeClient=execute_select(mydb,get_id())[0][0]
     #confirmation les information de client dans db
    check_client=f'''select codeClient,codeClient,nomClient,prenomClient,email
                    from Client
                    where nomClient='{nom}'
                    and prenomClient='{prenom}'
                    and email='{email}'
                    and codeClient={codeClient}
                    '''
    result_check_client=execute_select(mydb,check_client)
    if len(result_check_client)!=0:
        query_insert_Objet=f'''insert into Objet(codeclient, title, contenu) VALUE ({codeClient},"{object}","{message}")'''
        result_objet=execute_insert(mydb,query_insert_Objet)
        info=f"Merci {nom} {prenom}, nous avons bien reçu vos commentaires le {date_str} {time_str}."
        mydb.close()
        return render_template('confirmation.html', info=info)
    else:
        info=f"Désolé, nous n'avons pas reçu votre suggestion, veuillez la renvoyer."
        mydb.close()
        return render_template('confirmation.html',info=info)






def get_id():
    return "SELECT LAST_INSERT_ID();"



@app.route('/inforexap')
def inforexap():
    return render_template('inforexap.html')

if __name__ == '__main__':
    app.run()
    
    


