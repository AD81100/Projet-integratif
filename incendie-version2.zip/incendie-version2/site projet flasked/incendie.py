from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
from flask import url_for
from bs4 import BeautifulSoup
import os
import pymysql
import requests
import csv
import datetime

app = Flask(__name__)


def connect(host_name:str,user:str,pwd:str,datebase_name:str):
    try:
        mydb = pymysql.connect(
          host=host_name,
          user=user,
          password=pwd,
          database=datebase_name
        )
        print("Connection to database successful!")
        return mydb
    except:
        print("Connection to database failed!")


# select
def execute_select(mydb,query):
    mycursor = mydb.cursor()
    mycursor.execute(query)
    result = mycursor.fetchall()
    return result

# insert
def execute_insert(mydb,query):
    mycursor = mydb.cursor()
    mycursor.execute(query)
    mydb.commit()

# 爬虫
# def info_get():
#     url = "https://www.ouest-france.fr/faits-divers/incendie/"
#     response = requests.get(url)
#     html_content = response.text
#     soup = BeautifulSoup(html_content, 'html.parser')
    # 提取数据示例
    # data = []
    # 使用 BeautifulSoup 对象提取数据，将其存储在 data 列表中
    # for item in soup.find_all('div'):  # 根据需要更改 tag_name
    # 提取数据并添加到 data 列表中
        # data.append(item.text.strip())
    # 将数据写入 CSV 文件
    # with open('output.csv', 'w', newline='') as csvfile:  # 指定输出的文件名
        # writer = csv.writer(csvfile)
        # 写入 CSV 文件的表头
        # writer.writerow(['Column1', 'Column2', 'Column3'])  # 根据实际需求更改表头
        # 写入数据
        # for row in data:
        #     writer.writerow([row])  # 根据实际需求更改列名和数据

    # with open('html_content.html', 'w', encoding='utf-8') as f:
    #     f.write(html_content)
    # print("html_content 内容已保存到 html_content.html 文件中")

# def info_read():
#     with open('output.csv', 'r', encoding='utf-8') as f:
#         file_content = f.read()
#     print(file_content)


@app.route('/')
def index():
    return render_template('layout.html')

@app.route('/index')
def index_html():
    mydb=connect('localhost','root','code','nameBD') #输入自己的数据库信息
    query='''
        SELECT TitleNews,ContenuNews
        FROM News
        ORDER BY DateNews DESC
        LIMIT 2;
    '''
    result = execute_select(mydb, query)
    result = list(result)
    result = dealwith_news(result)
    mydb.close()
    return render_template('index.html',news=result)

@app.route('/prevision')
def prevision():
    return render_template('prevision.html')

@app.route('/france')
def france():
    return render_template('france.html')

@app.route('/corse')
def corse():
    return render_template('corse.html')

@app.route('/paca')
def paca():
    return render_template('paca.html')

@app.route('/aquitaine')
def aquitaine():
    return render_template('aquitaine.html')

@app.route('/occitanie')
def occitanie():
    return render_template('occitanie.html')

@app.route('/bourgogne')
def bourgogne():
    color = "red"
    return render_template('bourgogne.html', color=color)

@app.route('/information')
def information():
    mydb=connect('localhost','root','code','nameBD')  # 输入自己的信息
    # today = datetime.date.today()
    query='''
    SELECT TitleNews,ContenuNews
    FROM News
    ORDER BY DateNews DESC
    LIMIT 5
    '''
    result=execute_select(mydb,query)
    result = list(result)
    result=dealwith_news(result)
    mydb.close()
#[('',''),('','')]
    return render_template('information.html',news=result)

def dealwith_news(result:list)->dict:
    #dic={title1:contenu,title2:contenu}
    dic={}
    for i in result:
        dic[i[0]]=i[1]
    return dic


@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/MoreNews')
def MoreNews():
    return render_template('MoreNews.html')
@app.route('/NewsContenu')
def NewsContenu():
    return render_template('NewsContenu.html')

@app.route('/confirmation',methods=['GET','POST'])
def confirmation():
    if request.method == 'GET':
        nom=request.args.get('nom')
        prenom=request.args.get('prenom')
        email=request.args.get('email')
        telephone=request.args.get('telephone')
        object=request.args.get('object')
        message=request.args.get('message')

    else:
        nom=request.form['nom']
        prenom = request.form['prenom']
        email=request.form['email']
        telephone = request.form['telephone']
        object = request.form['object']
        message = request.form['message']
    today = datetime.date.today()
    now = datetime.datetime.now()
    date_str = today.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M:%S")

    # info=f"{nom},{prenom},{email}.{telephone},{object},{message},{date_str}"
    # return render_template('confirmation.html', info=info)

    # connect db
    mydb = connect('localhost', 'root', 'code', 'nameBD') #输入自己的数据库信息
    query=f'''
    insert into Client(nomClient, prenomClient, email, telephone, objet, message, Date)
    value ('{nom}','{prenom}','{email}','{telephone}','{object}','{message}','{date_str}')
    '''

    result_client=execute_insert(mydb,query)
    codeClient=execute_select(mydb,get_id())[0][0]
     #confirmation les information de client dans db
    check_client=f'''select codeClient,codeClient,nomClient,prenomClient,email
                    from Client
                    where nomClient='{nom}'
                    and prenomClient='{prenom}'
                    and email='{email}'
                    and codeClient={codeClient}
                    '''
    result_check_client=execute_select(mydb,check_client)
    if len(result_check_client)!=0:
        query_insert_Objet=f'''insert into Objet(codeclient, title, contenu) VALUE ({codeClient},"{object}","{message}")'''
        result_objet=execute_insert(mydb,query_insert_Objet)
        info=f"Merci {nom} {prenom}, nous avons bien reçu vos commentaires le {date_str} {time_str}."
        mydb.close()
        return render_template('confirmation.html', info=info)
    else:
        info=f"Désolé, nous n'avons pas reçu votre suggestion, veuillez la renvoyer."
        mydb.close()
        return render_template('confirmation.html',info=info)


def get_id():
    return "SELECT LAST_INSERT_ID();"

@app.route('/inforexap')
def inforexap():
    return render_template('inforexap.html')

if __name__ == '__main__':
    app.run()
    
    


